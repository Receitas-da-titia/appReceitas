package br.edu.iff.ccc.appreceitas.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller responsável pelo painel administrativo.
 *
 * Mapeia a rota relacionada a:
 * - RF12 (Controle Administrativo)
 *
 * Nesta fase apenas a rota e a view são mapeadas. O controle de acesso
 * (RNF06) e a lógica de gerenciamento de conteúdo serão implementados
 * em uma fase posterior.
 */
@Controller
public class AdminViewController {

    @GetMapping("/admin")
    public String painel() {
        return "admin";
    }
}
